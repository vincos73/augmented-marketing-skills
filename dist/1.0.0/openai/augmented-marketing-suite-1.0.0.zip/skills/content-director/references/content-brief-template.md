# Template del Content Brief

Usa questo template come libreria modulare per le sezioni del corpo. Quando restituisci un Content Brief completo, il frontmatter canonico è obbligatorio anche in conversazione. Non sostituirlo con una sezione narrativa sullo stato. Includi il nucleo necessario e aggiungi soltanto le sezioni che riducono ambiguità, rischio o reinterpretazione in produzione.

Nella raccomandazione preliminare non mostrare lo schema completo. Se il brief completo è già richiesto, consegnalo senza imporre una revisione preliminare separata; usa `bozza` per le decisioni aperte.

Classifica `editorial_path` rispetto alla richiesta iniziale:

- `trasformare` quando cambiano claim o premessa centrale, angolo, funzione, pubblico, forma o contesto;
- `produrre-con-vincoli` quando l'impostazione resta la stessa e cambiano soltanto qualifiche, esclusioni, approvazioni o condizioni d'uso.

```markdown
---
artifact: content-brief
version: 1
status: bozza | approvato | superato
title: "[Titolo di lavoro]"
scope: "[Singolo contenuto e perimetro]"
owner: "[Responsabile autorizzato]"
entry_mode: standalone | collegata
editorial_path: produrre | produrre-con-vincoli | trasformare | rafforzare-prima
created: YYYY-MM-DD
last_reviewed: YYYY-MM-DD
business_context_path: null
business_context_version: null
marketing_foundations_path: null
marketing_foundations_version: null
campaign_spec_path: null
campaign_spec_version: null
source_brief: null
supersedes: null
superseded_by: null
---

# Content Brief: [Titolo]

## Come usare questo brief

- Conserva queste decisioni durante la produzione.
- Leggi fonti e artefatti referenziati senza copiarli integralmente.
- Mantieni distinti elementi confermati, fonti, inferenze e incognite.
- Affida al builder le decisioni specialistiche del formato.
- Non considerare il brief come autorizzazione automatica a pubblicare o distribuire.

## Marcatori di provenienza

- `[C]` confermato dal responsabile
- `[S1]`, `[S2]`, ... sostenuto da una fonte elencata
- `[I]` inferito e in attesa di conferma
- `[?]` sconosciuto o irrisolto

Un'assunzione `[C]` è confermata come assunzione, non trasformata in fatto.

## Fonti e decisioni di partenza

| Riferimento | Percorso o fonte | Versione/data | Stato | Cosa sostiene | Limiti |
|---|---|---|---|---|---|
| Richiesta o brief | | | | | |
| Business Identity, se disponibile | | | | | |
| Marketing Foundations, se disponibili | | | | | |
| Campaign Spec, se disponibile | | | | | |

## Decisione editoriale

- **Percorso proposto o approvato, secondo lo stato:** produrre / produrre con vincoli / trasformare / rafforzare prima
- **Raccomandazione:**
- **Perché questa strada:**
- **Valore del materiale che preserva:**
- **Limite principale:**
- **Condizione che farebbe cambiare decisione:**
- **Scelta del responsabile diversa dalla raccomandazione:** no / sì, con motivazione

### Alternativa materiale, se esiste

- **Strada alternativa:**
- **Vantaggio:**
- **Trade-off:**
- **Perché non è la prima scelta:**

Nei casi dubbi aggiungi:

- **Miglior argomento per produrre:**
- **Miglior argomento per non produrre:**
- **Condizioni per una produzione difendibile:**

## Pubblico e funzione

- **Pubblico e situazione:**
- **Bisogno, tensione o domanda:**
- **Funzione editoriale:**
- **Cambiamento plausibile cercato:**
- **Azione o uso successivo, se pertinente:**
- **Che cosa il contenuto non deve promettere:**

## Idea centrale e angolo

- **Idea centrale:**
- **Angolo:**
- **Contributo distintivo:**
- **Tensione o domanda guida:**
- **Elementi da preservare:**
- **Elementi da escludere:**

## Affermazioni, prove e attribuzioni

| ID | Affermazione o elemento | Funzione | Fonte/prova | Uso consentito | Limite o verifica | Stato |
|---|---|---|---|---|---|---|
| C1 | | | | | | consentito / qualificare / verificare / escluso |

Citazioni, dati, comparazioni e attribuzioni devono restare collegati alla fonte. L'approvazione del responsabile non sostituisce una prova o un diritto mancante.

## Progressione semantica

| Passaggio | Funzione | Idea o prova | Cosa deve capire o fare il pubblico |
|---|---|---|---|
| | | | |

Descrivi passaggi logici come `problema → meccanismo → conseguenza → applicazione`. Numero di slide, scene, paragrafi, durata e montaggio appartengono al builder, salvo vincoli esterni confermati.

## Strada editoriale

- **Trattamento:**
- **Forma o esperienza raccomandata:**
- **Contesto principale di fruizione:**
- **Possibile estensione del singolo contenuto, se utile:**
- **Perché questa combinazione:**
- **Requisiti di accessibilità o fruizione:**

La raccomandazione resta valida anche se il builder non è disponibile. Una forma alternativa scelta per fattibilità deve riportare il trade-off.

## Brief per la produzione

- **Risultato che il contenuto deve ottenere:**
- **Fonte primaria da usare:**
- **Materiali disponibili:**
- **Elementi obbligatori:**
- **Libertà del builder o del team:**
- **Elementi vietati:**
- **Tono o standard applicabili:**
- **CTA o passaggio successivo, se pertinente:**
- **Builder, team o fornitore suggerito:**
- **Capacità osservata:** disponibile / non disponibile / da verificare

Il Content Brief non stabilisce copy finale, numero di unità, montaggio, composizione, impaginazione o resa, salvo vincoli esterni confermati.

## Diritti, vincoli e dipendenze

| Tema | Stato osservato | Impatto | Responsabile | Decisione o verifica richiesta | Comportamento prudente |
|---|---|---|---|---|---|
| | verificato / dichiarato / proposto / sconosciuto | | | | |

Considera quando pertinenti: diritti, licenze, consenso, privacy, compliance, brand, accessibilità, tempi, materiali, budget e disponibilità produttiva.

## Approvazioni e passaggi successivi

### Approvazione del Content Brief

- **Stato:** bozza / approvato / superato
- **Approvato da:**
- **Data:**
- **Punti aperti accettati:**
- **Autorizzazione al salvataggio:** sì / no

### Azioni successive

| Azione | Stato dell'autorizzazione | Responsabile | Condizioni | Evidenza osservata |
|---|---|---|---|---|
| Produzione | non richiesta / richiesta / autorizzata | | | |
| Revisione specialistica | non richiesta / richiesta / autorizzata | | | |
| Pubblicazione o distribuzione | non richiesta / richiesta / autorizzata | | | |
| Modifica di sistemi o account | non richiesta / richiesta / autorizzata | | | |

L'approvazione del brief non compila automaticamente le azioni successive come autorizzate.

## Passaggio alla produzione

- **Percorso produttivo previsto:** builder / strumento / team / fornitore / personalizzato
- **Passaggio realmente effettuato:**
- **Cosa manca prima della produzione:**
- **Cosa manca prima della pubblicazione:**
- **QA specialistico atteso:**
- **Destinazione dell'asset, quando esiste:**

## Fonti specifiche

| ID | Fonte | Data di accesso o fornitura | Cosa sostiene | Limiti, diritti o sensibilità |
|---|---|---|---|---|
| S1 | | | | |

## Registro modifiche

- v1 (YYYY-MM-DD): prima versione del Content Brief; indicare lo stato effettivo.
```

## Criterio di approvazione

Il Content Brief può diventare `approvato` quando:

- valore, pubblico, funzione, idea e angolo sono comprensibili;
- la forma è motivata editorialmente e non dalla disponibilità di uno strumento;
- affermazioni e attribuzioni sono sostenute, qualificate, da verificare o escluse;
- la progressione semantica conserva il significato necessario;
- il passaggio alla produzione distingue obblighi e libertà specialistiche;
- diritti, rischi, dipendenze e approvazioni sono visibili;
- il responsabile approva le scelte nel perimetro indicato.

Il salvataggio è distinto dall'approvazione editoriale: una richiesta di scrivere il file lo autorizza già, anche in bozza. Una direzione approvata può rimanere solo in conversazione. Conserva autorizzazioni espresse in precedenza senza richiederle nuovamente.

Un brief approvato può conservare blocchi di produzione o pubblicazione. Non può essere definito prodotto, pubblicato o distribuito finché tali stati non sono stati osservati.

## Percorso e versioning

Usa il percorso richiesto dall'utente. In sua assenza, per un salvataggio autorizzato adotta queste convenzioni:

Standalone:

```text
.agents/marketing/content/<content-slug>/content-brief.md
```

Collegato a una campagna:

```text
.agents/marketing/decisions/<decision-slug>/campaigns/<campaign-slug>/content/<content-slug>/content-brief.md
```

- Prima approvazione: `version: 1`, `status: approvato` e data corrente.
- Modifica sostanziale a pubblico, funzione, idea centrale, claim, forma o progressione: incrementa la versione intera e richiede nuova approvazione.
- Correzione di un refuso o collegamento: conserva versione e registro.
- Contenuto materialmente diverso: crea un nuovo fascicolo.
- Brief sostituito: imposta `status: superato` e indica `superseded_by`.

`Non produrre nella forma attuale` non crea automaticamente questo file. Se il responsabile approva una trasformazione o una produzione con vincoli, il brief registra la nuova strada. Una decisione negativa viene salvata soltanto su richiesta esplicita.

Se il workspace non è scrivibile dopo l'autorizzazione, restituisci una sola volta il contenuto completo e il percorso previsto senza dichiarare che il file esista. Durante test, simulazioni ed eval non scrivere nei percorsi canonici.
