# Pagina Augmented Marketing Suite per WordPress / Gutenberg

Contenuto della Suite **$release_status** · integrazione pagina **$plugin_version**.
Il pacchetto è predisposto per aggiornare la pagina esistente. Verificare il risultato sul sito dopo l'installazione.

## Inserimento della pagina

1. Installare `vincos-suite-page-$plugin_version.zip` da **Plugin → Aggiungi nuovo → Carica plugin**, nell’ambiente scelto per la prova.
2. Creare una pagina in bozza dal titolo “Augmented Marketing Suite”.
3. Inserire direttamente nella pagina un blocco Gutenberg **Shortcode** con `[vincos_marketing_suite]`, una volta sola. `gutenberg-shortcode.html` contiene lo stesso blocco serializzato.
4. Se disponibile, scegliere un modello a larghezza piena senza barra laterale. Il contenuto si adatta anche a una colonna stretta.
5. Mantenere visibile il titolo della pagina WordPress “Augmented Marketing Suite”: è l'unico H1. Il motto nell'hero è testo evidenziato.
6. Verificare nell’anteprima WordPress larghezza, titolo, menu, footer, catalogo, copia della richiesta e mobile, prima della pubblicazione.

Menu, logo, footer e cookie sono gestiti dal sito. Il pacchetto imposta title, description e testi social tramite i filtri Yoast quando lo shortcode è presente; l'immagine social sarà gestita separatamente. Non aggiunge un secondo header Vincos: il contenuto parte direttamente dall’hero della Suite. Non inserire `index.html` nell’editor, perché include soltanto la cornice dimostrativa locale.

## Aggiornare una skill o aggiungerne una

I contenuti si gestiscono nel progetto sorgente, in **`content/suite.json`**. Ogni skill ha un identificatore stabile, un’area, un titolo, una descrizione, il risultato e un esempio. L’ordine dell’elenco determina l’ordine delle schede in ciascuna area.

1. Modificare una scheda o aggiungere una voce in `skills`. Per una nuova area aggiungere anche una voce in `groups`.
2. Dalla cartella `prototypes/vincos-suite-page` eseguire `python3 scripts/build.py`.
3. Controllare l’anteprima; il catalogo, i conteggi, gli esempi e il pacchetto WordPress vengono rigenerati insieme.
4. Per distribuire un aggiornamento, incrementare anche `suite.plugin_version`, rigenerare il pacchetto e sostituire il plugin precedente con lo ZIP prodotto. Lo shortcode nella pagina rimane lo stesso. Svuotare l’eventuale cache della pagina dopo l’aggiornamento.

La versione della Suite in `suite.version` genera etichetta e link alla release. Il campo facoltativo `badge` mostra un’etichetta editoriale; `introduced_in` mostra “Novità” solo se coincide con la versione corrente. Le affermazioni e le FAQ della release vanno comunque rilette quando cambia il prodotto.

La sezione sul metodo usa `page.method_intro`, `page.principles` e `page.method_visual`. Per sostituire il diagramma, copiare il nuovo file raster in `assets/`, aggiornare `for_version`, `src`, `alt` e `caption`, incrementare `suite.plugin_version` e rigenerare. La build rifiuta un diagramma associato a una versione diversa, per evitare conteggi visivi obsoleti. Il plugin risolve automaticamente il percorso dell’immagine; il diagramma occupa l’intera larghezza disponibile della sezione e si riduce in modo proporzionale senza creare scorrimento orizzontale.

Il catalogo non contiene un limite fisso di aree o skill. Tutti i testi sono già nell’HTML: rimangono leggibili senza JavaScript e non dipendono dal caricamento di dati esterni.

**Gutenberg ospita lo shortcode; le singole schede non sono blocchi modificabili nell’editor visuale.** Si aggiornano dalla fonte unica e si rigenera il pacchetto. Non modificare a mano `page-content.html` o le copie nella cartella `wordpress/vincos-suite-page`: sono file generati.

## Confini dell’integrazione

- Stili e interazioni sono limitati a `#vincos-suite`; l’impaginazione segue la larghezza del contenitore. Font, licenza e diagramma sono inclusi localmente nel plugin.
- Gli asset si caricano solo nei contenuti singoli che contengono direttamente lo shortcode. Blocchi sincronizzati, widget e inserimento da template richiedono un adattamento: in questa versione usare il blocco direttamente nella pagina.
- Il plugin non crea pagine, non scrive opzioni o dati, non aggiunge tracciamento e non pubblica. I filtri SEO sono limitati alla pagina che contiene direttamente lo shortcode.
- Il `noindex` appartiene esclusivamente all’anteprima locale e non viene incluso nel contenuto WordPress.
- La verifica locale copre il browser e una simulazione di tema con colonna da 760 px e stili esterni. Restano da provare WordPress/PHP reali, il tema del sito e gli eventuali sistemi di cache e ottimizzazione.
- La versione del plugin pagina serve a distribuire questa integrazione e aggiornare la cache degli asset; è distinta dalla versione della Marketing Suite.

Riferimenti: [blocco Shortcode](https://wordpress.org/documentation/article/shortcode-block/), [API Shortcode](https://developer.wordpress.org/plugins/shortcodes/), [caricamento degli stili](https://developer.wordpress.org/reference/functions/wp_enqueue_style/).
