'use strict';

(() => {
  function init() {
    const root = document.getElementById('vincos-suite');
    if (!root || root.dataset.vmsReady === 'true') return;
    const $ = selector => root.querySelector(selector);
    const $$ = selector => [...root.querySelectorAll(selector)];
    const localId = id => {
      const element = document.getElementById(id);
      return element && root.contains(element) ? element : null;
    };

    // Each list discovers its own panels. Adding a skill or area needs no JS change.
    function wireTabs(list) {
      const tabs = [...list.querySelectorAll('button[aria-controls]')];
      const panels = tabs.map(tab => localId(tab.getAttribute('aria-controls')));
      // An incomplete component stays readable; other components can still work.
      if (!tabs.length || panels.some(panel => !panel) || new Set(panels).size !== panels.length) return;
      list.setAttribute('role', 'tablist');
      tabs.forEach((tab, index) => {
        tab.setAttribute('role', 'tab');
        panels[index].setAttribute('role', 'tabpanel');
        panels[index].setAttribute('aria-labelledby', tab.id);
        panels[index].tabIndex = 0;
        panels[index].dataset.vmsPanelReady = 'true';
      });
      const activate = selected => {
        tabs.forEach((tab, index) => {
          const active = tab === selected;
          const wasHidden = panels[index].hidden;
          tab.setAttribute('aria-selected', String(active));
          tab.tabIndex = active ? 0 : -1;
          panels[index].hidden = !active;
          if (!active) panels[index].classList.remove('vms-panel-enter');
          else if (wasHidden && list.dataset.vmsTabsReady === 'true') panels[index].classList.add('vms-panel-enter');
        });
      };
      tabs.forEach(tab => tab.addEventListener('click', () => activate(tab)));
      list.addEventListener('keydown', event => {
        const current = tabs.indexOf(event.target);
        if (current < 0) return;
        // Read the current layout, including a resize that preceded the observer callback.
        const style = getComputedStyle(list);
        const vertical = style.display === 'flex' && style.flexDirection === 'column';
        list.setAttribute('aria-orientation', vertical ? 'vertical' : 'horizontal');
        let next;
        if (event.key === (vertical ? 'ArrowDown' : 'ArrowRight')) next = (current + 1) % tabs.length;
        else if (event.key === (vertical ? 'ArrowUp' : 'ArrowLeft')) next = (current - 1 + tabs.length) % tabs.length;
        else if (event.key === 'Home') next = 0;
        else if (event.key === 'End') next = tabs.length - 1;
        else return;
        event.preventDefault();
        tabs[next].focus();
        activate(tabs[next]);
      });
      activate(tabs.find(tab => tab.getAttribute('aria-selected') === 'true') || tabs[0]);
      list.dataset.vmsTabsReady = 'true';
      const syncOrientation = () => {
        const style = getComputedStyle(list);
        list.setAttribute('aria-orientation', style.display === 'flex' && style.flexDirection === 'column' ? 'vertical' : 'horizontal');
      };
      syncOrientation();
      if ('ResizeObserver' in window) new ResizeObserver(syncOrientation).observe(root);
    }
    $$('[data-vms-tabs]').forEach(wireTabs);

    const aliases = { skill: 'vms-skill', metodo: 'vms-metodo', inizia: 'vms-inizia' };
    const hashTarget = hash => {
      let id;
      try { id = decodeURIComponent(hash.replace(/^#/, '')); } catch { return null; }
      return localId(aliases[id] || id);
    };
    function reveal(target) {
      const panel = target.closest('[data-vms-panel-ready]');
      if (!panel || !panel.hidden) return;
      const tab = $$('[role="tab"]').find(item => item.getAttribute('aria-controls') === panel.id);
      if (tab) tab.click();
    }
    root.addEventListener('click', event => {
      const link = event.target.closest('a[href^="#"]');
      if (!link || !root.contains(link) || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      const target = hashTarget(link.getAttribute('href'));
      if (!target) return;
      event.preventDefault();
      reveal(target);
      const focusTarget = target.querySelector('h2,h3') || target;
      if (!focusTarget.hasAttribute('tabindex')) {
        focusTarget.tabIndex = -1;
        focusTarget.addEventListener('blur', () => focusTarget.removeAttribute('tabindex'), { once: true });
      }
      focusTarget.focus({ preventScroll: true });
      target.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
      try { window.history.replaceState(null, '', '#' + target.id); } catch { /* File previews may restrict History API. */ }
    });
    const followHash = () => {
      const target = hashTarget(window.location.hash);
      if (target) {
        reveal(target);
        const align = () => {
          if (hashTarget(window.location.hash) === target) target.scrollIntoView({ block: 'start' });
        };
        requestAnimationFrame(align);
        if (document.fonts && document.fonts.ready) document.fonts.ready.then(align);
        if (document.readyState !== 'complete') window.addEventListener('load', align, { once: true });
      }
    };
    window.addEventListener('hashchange', followHash);

    const copyButton = $('#vms-copy-prompt');
    const prompt = $('#vms-starter-prompt');
    const status = $('#vms-copy-status');
    if (copyButton && prompt && status) {
      root.classList.add('vms-copy-ready');
      const originalButton = copyButton.innerHTML;
      let resetTimer;
      const restoreCopyButton = () => {
        copyButton.classList.remove('is-success');
        copyButton.innerHTML = originalButton;
      };
      copyButton.addEventListener('click', async () => {
        window.clearTimeout(resetTimer);
        restoreCopyButton();
        copyButton.disabled = true;
        copyButton.textContent = 'Copia in corso…';
        status.textContent = '';
        try {
          if (!navigator.clipboard || !window.isSecureContext) throw new Error('clipboard unavailable');
          await navigator.clipboard.writeText(prompt.textContent);
          status.textContent = 'Richiesta copiata. Incollala nel tuo assistente e adattala al tuo caso.';
          copyButton.textContent = 'Richiesta copiata';
          copyButton.classList.add('is-success');
          resetTimer = window.setTimeout(() => {
            restoreCopyButton();
            status.textContent = '';
          }, 2200);
        } catch {
          const range = document.createRange();
          range.selectNodeContents(prompt);
          const selection = window.getSelection();
          if (selection) { selection.removeAllRanges(); selection.addRange(range); }
          status.textContent = 'La copia automatica non è disponibile. Seleziona il testo e usa il comando Copia del tuo dispositivo.';
          restoreCopyButton();
        } finally { copyButton.disabled = false; }
      });
    }
    root.dataset.vmsReady = 'true';
    followHash();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
