#!/usr/bin/env python3
"""Render the shared static page and WordPress package; Python standard library only."""
import argparse
import hashlib
import html
import io
import json
from pathlib import Path
import re
import string
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
MODULES = ('hero', 'method', 'catalog', 'start', 'faq')


def icon(name):
    paths = {
        'down': 'M12 4v16m-7-7 7 7 7-7',
        'up-right': 'M7 17 17 7M7 7h10v10',
        'chevron': 'm6 9 6 6 6-6',
        'copy': 'M8 8h12v13H8zM16 8V3H3v13h5',
    }
    return f'<svg class="vms-icon vms-icon-{name}" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="{paths[name]}"/></svg>'


def validate(data):
    suite = data['suite']
    if not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+(?:-[a-z0-9.]+)?', suite['version']):
        raise ValueError('Versione della Suite non valida.')
    if not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', suite['plugin_version']):
        raise ValueError('Versione del plugin pagina non valida.')
    if not suite['repository'].startswith('https://github.com/'):
        raise ValueError('Il repository pubblico deve usare HTTPS su GitHub.')
    version = suite['version']
    expected_archives = {
        'chatgpt-codex': f'augmented-marketing-suite-public-{next(p.get("version", version) for p in data["platforms"] if p["id"] == "chatgpt-codex")}.zip',
        'claude': f'augmented-marketing-suite-claude-v{version}.zip',
    }
    if {row['id'] for row in data['platforms']} != set(expected_archives):
        raise ValueError('ChatGPT e Codex condividono un download; Claude ne usa uno dedicato.')
    for platform in data['platforms']:
        if platform['archive'].format(version=platform.get('version', version)) != expected_archives[platform['id']]:
            raise ValueError(f'Archivio non corretto per {platform["id"]}.')
    for key in ('groups', 'skills', 'platforms'):
        ids = [row['id'] for row in data[key]]
        if not ids or len(ids) != len(set(ids)):
            raise ValueError(f'{key}: elenco vuoto o identificatori duplicati.')
        if any(not re.fullmatch(r'[a-z][a-z0-9-]*', value) for value in ids):
            raise ValueError(f'{key}: usare identificatori stabili, minuscoli e con trattini.')
    groups = {row['id'] for row in data['groups']}
    if suite['default_group'] not in groups:
        raise ValueError('L’area iniziale non esiste.')
    for skill in data['skills']:
        if skill['group'] not in groups:
            raise ValueError(f'Area sconosciuta per {skill["id"]}.')
        for key in ('title', 'description', 'output', 'example'):
            if not skill[key].strip():
                raise ValueError(f'{skill["id"]}: campo {key} vuoto.')
    if groups != {row['group'] for row in data['skills']}:
        raise ValueError('Ogni area pubblicata deve contenere almeno una skill.')
    if data['page']['starter_skill'] not in {row['id'] for row in data['skills']}:
        raise ValueError('La richiesta iniziale deve riferirsi a una skill del catalogo.')
    method_intro = data['page']['method_intro']
    if not isinstance(method_intro, list) or not method_intro or any(not isinstance(row, str) or not row.strip() for row in method_intro):
        raise ValueError('La spiegazione del metodo deve contenere uno o più paragrafi.')
    visual = data['page']['method_visual']
    if visual['for_version'] != suite['version']:
        raise ValueError('Il diagramma deve essere verificato per la versione corrente della Suite.')
    if not re.fullmatch(r'assets/[a-z0-9][a-z0-9._-]*\.(?:png|jpg|jpeg|webp)', visual['src']):
        raise ValueError('Il diagramma deve essere un asset raster locale sicuro.')
    if not (ROOT / visual['src']).is_file() or not visual['alt'].strip() or not visual['caption'].strip():
        raise ValueError('Diagramma, testo alternativo e didascalia sono obbligatori.')


def render(data):
    validate(data)
    suite, page = data['suite'], data['page']
    count = len(data['skills'])
    label = suite['version'].partition('-')[2] or suite['version']
    tag = 'augmented-marketing-suite-v' + suite['version']
    openai_version = next(p.get('version', suite['version']) for p in data['platforms'] if p['id'] == 'chatgpt-codex')
    openai_tag = 'augmented-marketing-suite-v' + openai_version
    repo = suite['repository'].rstrip('/')
    facts = {'count': count, 'release_label': label, 'release_status': suite['status'], 'version': suite['version']}

    def text(value):
        return html.escape(value.format_map(facts), quote=True)

    def php_string(value):
        return "'" + value.format_map(facts).replace('\\', '\\\\').replace("'", "\\'") + "'"

    def heading(value):
        return '<br>'.join(text(line) for line in value.splitlines())

    def template(name, values):
        return string.Template((ROOT / 'templates' / name).read_text()).substitute(values)

    values = {f'icon_{name.replace("-", "_")}': icon(name) for name in ('down', 'up-right', 'chevron', 'copy')}
    values.update({
        'suite_name': text(suite['name']), 'release_label': text(label), 'release_status': text(suite['status']),
        'release_url': f'{repo}/releases/tag/{openai_tag}',
        'install_url': f'{repo}/blob/{openai_tag}/INSTALLAZIONE.md',
        'review_url': f'{repo}/blob/{openai_tag}/{suite["review_path"]}',
        'headline': text(page['headline'][0]) + '<br><span>' + text(page['headline'][1]) + '</span>',
        'hero_intro': text(page['intro']),
        'quick_summary': text(page['quick_summary']),
        'method_title': heading(page['method_title']),
        'method_intro': '\n'.join(f'        <p>{text(paragraph)}</p>' for paragraph in page['method_intro']),
        'method_visual_src': text(page['method_visual']['src']),
        'method_visual_alt': text(page['method_visual']['alt']),
        'method_visual_caption': text(page['method_visual']['caption']),
        'catalog_title': heading(page['catalog_title']), 'catalog_intro': text(page['catalog_intro']),
        'start_title': heading(page['start_title']), 'start_intro': text(page['start_intro']),
        'starter_context': text(page['starter_context']), 'project_credit': text(page['credit']),
        'starter_prompt': text(next(s['example'] for s in data['skills'] if s['id'] == page['starter_skill'])),
    })
    values['principles'] = '\n'.join(
        f'        <li><h3>{text(p["title"])}</h3><p>{text(p["text"])}</p></li>' for p in page['principles'])

    tabs, panels = [], []
    for group in data['groups']:
        gid = group['id']
        members = [s for s in data['skills'] if s['group'] == gid]
        active = str(gid == suite['default_group']).lower()
        tabs.append(f'        <button type="button" id="vms-tab-{gid}" aria-selected="{active}" aria-controls="vms-panel-{gid}"><span>{text(group["label"])}</span><span class="vms-count" aria-label="{len(members)} skill">{len(members)}</span></button>')
        rows = []
        for skill in members:
            fields = dict(values)
            fields.update({f'skill_{k}': text(skill[k]) for k in ('id', 'title', 'description', 'output', 'example')})
            fields['skill_url'] = f'{repo}/tree/{tag}/skills/{skill["id"]}'
            badge = skill.get('badge') or ('Novità' if skill.get('introduced_in') == suite['version'] else '')
            fields['skill_badge'] = f'<span class="vms-skill-badge">{text(badge)}</span>' if badge else ''
            rows.append(template('skill.html', fields))
        panels.append(f'        <div class="vms-catalog-panel" id="vms-panel-{gid}" aria-labelledby="vms-group-heading-{gid}">\n'
                      f'          <h3 class="vms-fallback-heading" id="vms-group-heading-{gid}">{text(group["label"])}</h3>\n'
                      f'          <p class="vms-panel-intro">{text(group["intro"])}</p>\n' + ''.join(rows) + '        </div>')
    values['catalog_tabs'], values['catalog_panels'] = '\n'.join(tabs), '\n'.join(panels)

    tabs, panels = [], []
    for index, platform in enumerate(data['platforms']):
        pid = platform['id']
        platform_version = platform.get('version', suite['version'])
        platform_facts = dict(facts, version=platform_version)
        archive = platform['archive'].format_map(platform_facts)
        platform_tag = 'augmented-marketing-suite-v' + platform_version
        download_url = f'{repo}/releases/download/{platform_tag}/{archive}'
        tabs.append(f'            <button type="button" id="vms-platform-{pid}" aria-selected="{str(index == 0).lower()}" aria-controls="vms-platform-panel-{pid}">{text(platform["label"])}</button>')
        panels.append(f'            <div class="vms-platform-panel" id="vms-platform-panel-{pid}" aria-labelledby="vms-platform-heading-{pid}">'
                      f'<h4 class="vms-fallback-heading" id="vms-platform-heading-{pid}">{text(platform["label"])}</h4>'
                      f'<p class="vms-platform-title">{text(platform["title"])}</p><p class="vms-platform-description">{html.escape(platform["description"].format_map(platform_facts), quote=True)}</p>'
                      f'<a class="vms-platform-download" href="{download_url}" target="_blank" rel="noopener noreferrer">{text(platform["download_label"])} {icon("up-right")}</a></div>')
    values['platform_tabs'], values['platform_panels'] = '\n'.join(tabs), '\n'.join(panels)
    faq = []
    for row in data['faq']:
        extra = ''
        if row.get('link'):
            url = values[row['link'] + '_url']
            extra = f' <a href="{url}" target="_blank" rel="noopener noreferrer">{text(row["link_label"])}</a>.'
        faq.append(f'      <details><summary>{text(row["question"])} {icon("chevron")}</summary><p>{text(row["answer"])}{extra}</p></details>')
    values['faq_items'] = '\n'.join(faq)

    fragment = '<section id="vincos-suite" class="vincos-suite" lang="it" aria-label="' + text(suite['name']) + '">\n'
    fragment += '\n'.join(template(name + '.html', values) for name in MODULES) + '</section>\n'
    shell_values = {
        'page_content': fragment, 'meta_description': text(page['meta_description']),
        'page_title': text(page['meta_title']),
    }
    outputs = {
        'page-content.html': fragment.encode(),
        'index.html': template('preview.html', shell_values).encode(),
        'review/wordpress-container.html': template('wordpress-container.html', dict(shell_values, page_content=fragment.replace('src="assets/', 'src="../assets/'))).encode(),
    }

    plugin_version = suite['plugin_version']
    guide = template('wordpress/LEGGIMI.md', dict(values, plugin_version=plugin_version)).encode()
    outputs['wordpress/LEGGIMI.md'] = guide
    package = {
        'page-content.html': fragment.encode(),
        'vincos-suite-page.php': (ROOT / 'templates/wordpress/vincos-suite-page.php').read_text()
            .replace('{{plugin_version}}', plugin_version)
            .replace('{{meta_title}}', php_string(page['meta_title']))
            .replace('{{meta_description}}', php_string(page['meta_description'])).encode(),
        'LEGGIMI.md': guide,
    }
    for path in ('styles.css', 'app.js', page['method_visual']['src'], 'assets/Barlow-Regular.ttf', 'assets/Barlow-Medium.ttf', 'assets/Barlow-Bold.ttf', 'assets/OFL.txt'):
        package[path] = (ROOT / path).read_bytes()
    for path, content in package.items():
        outputs['wordpress/vincos-suite-page/' + path] = content
    # Fixed timestamps make unchanged input produce the same reviewable archive.
    archive = io.BytesIO()
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as zipped:
        for path, content in sorted(package.items()):
            entry = zipfile.ZipInfo('vincos-suite-page/' + path, (2026, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            zipped.writestr(entry, content)
    zip_name = f'vincos-suite-page-{plugin_version}.zip'
    outputs['wordpress/' + zip_name] = archive.getvalue()
    digest = hashlib.sha256(archive.getvalue()).hexdigest()
    outputs['wordpress/SHA256SUMS'] = f'{digest}  {zip_name}\n'.encode()
    return outputs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=ROOT / 'content/suite.json')
    parser.add_argument('--output', type=Path, default=ROOT, help='Optional isolated output directory.')
    parser.add_argument('--check', action='store_true', help='Verify generated files without writing.')
    args = parser.parse_args()
    try:
        data = json.loads(args.data.read_text())
        outputs = render(data)
    except (ValueError, KeyError, OSError) as error:
        parser.exit(1, f'Build non riuscita: {error}\n')
    differences = []
    for name, content in outputs.items():
        dest = args.output / name
        if args.check:
            if not dest.is_file() or dest.read_bytes() != content:
                differences.append(name)
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(content)
    if differences:
        parser.exit(1, 'File da rigenerare:\n' + '\n'.join(differences) + '\n')
    print(f'{"Verificati" if args.check else "Generati"} {len(outputs)} file; {len(data["skills"])} skill in {len(data["groups"])} aree; Suite {data["suite"]["version"]}.')


if __name__ == '__main__':
    sys.exit(main())
