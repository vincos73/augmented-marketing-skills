#!/usr/bin/env python3
"""Check release coverage, generated artifacts and future catalog growth."""
import copy
from html.parser import HTMLParser
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('suite_page_build', ROOT / 'scripts/build.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
data = json.loads((ROOT / 'content/suite.json').read_text())
results = []


def check(name, condition):
    results.append({'check': name, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(name)


class Markup(HTMLParser):
    def __init__(self, source):
        super().__init__()
        self.ids, self.tags, self.links = [], [], []
        self.feed(source)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.tags.append(tag)
        if attrs.get('id'):
            self.ids.append(attrs['id'])
        if tag == 'a':
            self.links.append(attrs.get('href', ''))


outputs = builder.render(data)
fragment = outputs['page-content.html'].decode()
markup = Markup(fragment)
check('Unique anchors in the fragment', len(markup.ids) == len(set(markup.ids)))
check('Every internal link has a target', all(link[1:] in markup.ids for link in markup.links if link.startswith('#')))
check('WordPress fragment excludes the preview shell and inline code', not set(markup.tags) & {'html', 'head', 'body', 'header', 'footer', 'main', 'script', 'style', 'link', 'meta'})
check('WordPress content starts with the Suite and omits the Vincos site header', fragment.lstrip().startswith('<section id="vincos-suite"') and 'vms-preview-header' not in fragment and 'vincos-lockup' not in fragment)
check('Single useful in-page action; no adjacent-section CTAs', [a for a in markup.links if a.startswith('#')] == ['#vms-skill'])
check('No old example box or closing CTA section', 'vms-example-board' not in fragment and 'vms-closing-section' not in fragment)
check('No obsolete beta or old catalog copy', 'beta.' not in fragment.lower() and 'nove skill' not in fragment.lower() and 'undici skill' not in fragment.lower())
check('FAQ explains Suite continuity, first use and platforms without duplicating Claude installation', all(question in fragment for question in ('Che cos’è una skill?', 'Perché usare la Suite invece di un prompt?', 'Serve saper programmare?', 'Funziona con ChatGPT gratuito?')) and 'documenti riutilizzabili' in fragment and 'non autorizza una pubblicazione o una spesa pubblicitaria' in fragment and 'Come si installa in Claude?' not in fragment and 'No. Lavori in conversazione' in fragment)
check('Hero leaves the site page title as the sole H1', 'h1' not in markup.tags and 'class="vms-hero-title"' in fragment)
check('OpenAI 1.0.2 and Claude 1.0.0 downloads are distinct', fragment.count('id="vms-platform-chatgpt-codex"') == 1 and fragment.count('Scarica il plugin per ChatGPT e Codex') == 1 and '/releases/download/augmented-marketing-suite-v1.0.2/augmented-marketing-suite-public-1.0.2.zip' in fragment and '/releases/download/augmented-marketing-suite-v1.0.0/augmented-marketing-suite-claude-v1.0.0.zip' in fragment and 'in review' in fragment)
check('Method explains reusable foundations and guided thinking', all(copy in fragment for copy in ('sistema operativo per il tuo marketing', 'documenti riutilizzabili', 'Guida il tuo pensiero')))
check('Catalog places brand voice in foundations without a Claude badge', fragment.index('id="vms-panel-foundations"') < fragment.index('id="vms-skill-setup-brand-voice"') < fragment.index('id="vms-panel-strategy"') and 'Ora anche su Claude' not in fragment)
visual_path = data['page']['method_visual']['src']
check('Method diagram follows the two explanatory columns at full section width without a scrolling frame', f'<div class="vms-method-intro">' in fragment and fragment.index('<div class="vms-method-intro">') < fragment.index('<ul class="vms-method-principles">') < fragment.index(f'src="{visual_path}"') and data['page']['method_visual']['alt'] in fragment and 'vms-method-visual-frame' not in fragment and 'Scorri il diagramma' not in fragment)
check('All generated outputs match disk', all((ROOT / p).read_bytes() == body for p, body in outputs.items()))
check('Build and ZIP are deterministic', outputs == builder.render(data))

suite_version = data['suite']['version']
release_root = ROOT.parents[1] / 'dist' / data['suite']['distribution_dir']
manifest = json.loads((release_root / 'manifest.json').read_text())
packages = {row['archive']: row for row in manifest['packages']}
openai_archive = f'openai/augmented-marketing-suite-{suite_version}.zip'
claude_archive = f'claude/augmented-marketing-suite-claude-v{suite_version}.zip'
release_zip = release_root / openai_archive
with zipfile.ZipFile(release_zip) as archive:
    shipped = {path.split('/')[-2] for path in archive.namelist() if path.endswith('/SKILL.md') and '/skills/' in '/' + path}
catalog = {s['id'] for s in data['skills']}
portable = {skill for row in manifest['packages'] if row['archive'].startswith('agent-skills/') for skill in row['skills']}
check('Release manifest matches the stable version', manifest['suite_version'] == suite_version and manifest['state'] == 'built')
check('Catalog equals all skills in the OpenAI plugin', catalog == shipped == set(packages[openai_archive]['skills']))
check('Claude plugin contains the same complete catalog', catalog == set(packages[claude_archive]['skills']))
check('Individual archives cover every specialist skill', catalog - {'augmented-marketing-assistant'} == portable)

zip_path = f'wordpress/vincos-suite-page-{data["suite"]["plugin_version"]}.zip'
with zipfile.ZipFile(io.BytesIO(outputs[zip_path])) as archive:
    check('WordPress ZIP passes CRC verification', archive.testzip() is None)
    check('ZIP contents match the generated package byte for byte', all(outputs['wordpress/' + p] == archive.read(p) for p in archive.namelist()))
    check('ZIP has a single plugin root', {p.split('/')[0] for p in archive.namelist()} == {'vincos-suite-page'})
    check('WordPress ZIP contains the method diagram', 'vincos-suite-page/' + visual_path in archive.namelist())
    check('WordPress ZIP does not distribute a duplicate site header', all('vincos-lockup' not in path for path in archive.namelist()))
check('Styles, script and diagram match the package', all((ROOT / name).read_bytes() == outputs['wordpress/vincos-suite-page/' + name] for name in ['styles.css', 'app.js', visual_path]))
check('WordPress render resolves local image paths through the plugin URL', "str_replace('src=\"assets/" in outputs['wordpress/vincos-suite-page/vincos-suite-page.php'].decode())

# Render a deliberately expanded catalog without changing the actual page or data.
growth = copy.deepcopy(data)
growth['groups'].append({'id': 'future-test', 'label': 'Area di prova', 'intro': 'Area aggiunta soltanto per verificare la crescita del catalogo.'})
for slug, group in [('additional-test', 'content'), ('future-test-skill', 'future-test')]:
    growth['skills'].append({'id': slug, 'group': group, 'title': 'Skill di prova', 'description': 'Descrizione di prova.', 'output': 'Risultato di prova.', 'example': 'Esempio di prova.'})
expanded = builder.render(growth)
expanded_html = expanded['page-content.html'].decode()
expanded_count = len(growth['skills'])
expanded_areas = len(growth['groups'])
expanded_content_count = sum(skill['group'] == 'content' for skill in growth['skills'])
check('Adding a skill updates its existing area count', f'aria-label="{expanded_content_count} skill">{expanded_content_count}</span>' in expanded_html)
check('Adding an area needs no template or JS edits', 'id="vms-panel-future-test"' in expanded_html and expanded_html.count('class="vms-catalog-panel"') == expanded_areas)
check('Total count updates across product text', f'{expanded_count} skill per' in expanded_html)

for name, mutation in [
    ('Duplicate skill identifiers are rejected', lambda d: d['skills'].append(d['skills'][0])),
    ('Unknown skill areas are rejected', lambda d: d['skills'][0].update(group='missing')),
    ('Missing default area is rejected', lambda d: d['suite'].update(default_group='missing')),
    ('A diagram from another Suite version is rejected', lambda d: d['page']['method_visual'].update(for_version='0.0.0')),
]:
    invalid = copy.deepcopy(data)
    mutation(invalid)
    try:
        builder.render(invalid)
    except ValueError:
        check(name, True)
    else:
        check(name, False)

temporary = Path(tempfile.mkdtemp(prefix='vincos-suite-qa-')) / 'growth.html'
temporary.write_bytes(expanded['index.html'])
report = {'suite_version': suite_version, 'plugin_version': data['suite']['plugin_version'], 'checks': results,
          'temporary_growth_fixture': str(temporary), 'wordpress_runtime_tested': False}
(ROOT / 'review/qa-build.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': len(results), 'growth_fixture': str(temporary), 'wordpress_runtime_tested': False}))
