<?php
/**
 * Plugin Name: Vincos — Pagina Augmented Marketing Suite
 * Description: Inserisce la pagina esplicativa della Suite con lo shortcode [vincos_marketing_suite].
 * Version: 0.12.3
 * Author: Vincenzo Cosenza
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

// No settings, database changes, external requests or global theme overrides.
function vincos_suite_page_has_content() {
    if (!is_singular()) {
        return false;
    }
    $post = get_queried_object();
    return $post instanceof WP_Post
        && has_shortcode($post->post_content, 'vincos_marketing_suite');
}

// Keep the page-specific search and social text aligned with the visible Suite.
function vincos_suite_page_meta_title($value) {
    return vincos_suite_page_has_content() ? 'Augmented Marketing Suite: 12 skill IA per il marketing | Vincos' : $value;
}
function vincos_suite_page_meta_description($value) {
    return vincos_suite_page_has_content() ? '12 skill di IA per marketer e team: contesto aziendale, strategia, campagne e contenuti. Scopri i pacchetti per ChatGPT, Codex e Claude.' : $value;
}
function vincos_suite_page_og_type($value) {
    return vincos_suite_page_has_content() ? 'website' : $value;
}
function vincos_suite_page_document_title($parts) {
    if (vincos_suite_page_has_content()) {
        $parts['title'] = 'Augmented Marketing Suite: 12 skill IA per il marketing | Vincos';
        unset($parts['site']);
    }
    return $parts;
}
add_filter('document_title_parts', 'vincos_suite_page_document_title');
add_filter('wpseo_title', 'vincos_suite_page_meta_title');
add_filter('wpseo_metadesc', 'vincos_suite_page_meta_description');
add_filter('wpseo_opengraph_title', 'vincos_suite_page_meta_title');
add_filter('wpseo_opengraph_desc', 'vincos_suite_page_meta_description');
add_filter('wpseo_opengraph_type', 'vincos_suite_page_og_type');
add_filter('wpseo_twitter_title', 'vincos_suite_page_meta_title');
add_filter('wpseo_twitter_description', 'vincos_suite_page_meta_description');

function vincos_suite_page_assets() {
    if (!vincos_suite_page_has_content()) {
        return;
    }
    $base = plugin_dir_url(__FILE__);
    wp_enqueue_style('vincos-suite-page', $base . 'styles.css', array(), '0.12.3');
    wp_enqueue_script('vincos-suite-page', $base . 'app.js', array(), '0.12.3', true);
}
add_action('wp_enqueue_scripts', 'vincos_suite_page_assets', 30);

function vincos_suite_page_render() {
    // The page contains named anchors, so only one instance belongs in a document.
    static $rendered = false;
    if ($rendered) {
        return '';
    }
    $path = __DIR__ . '/page-content.html';
    if (!is_readable($path)) {
        return '<p>' . esc_html('Il contenuto della Suite non è disponibile. Ripristina i file del pacchetto.') . '</p>';
    }
    $content = file_get_contents($path);
    if (false === $content) {
        return '<p>' . esc_html('Non è stato possibile leggere la pagina della Suite. Riprova dopo aver verificato il pacchetto.') . '</p>';
    }
    $asset_base = esc_url(plugin_dir_url(__FILE__) . 'assets/');
    $content = str_replace('src="assets/', 'src="' . $asset_base, $content);
    $rendered = true;
    // Trusted, versioned local HTML. No request data or shortcode parameters are interpolated.
    return $content;
}
add_shortcode('vincos_marketing_suite', 'vincos_suite_page_render');
