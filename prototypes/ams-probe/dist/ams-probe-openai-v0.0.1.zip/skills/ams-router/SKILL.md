---
name: ams-router
description: "Punto di ingresso sperimentale per chiarire una sfida di marketing o confrontare direzioni nella stessa conversazione. Usalo quando l'utente chiede aiuto di marketing senza invocare direttamente uno specialista AMS Probe; non usarlo per campagne o produzione di contenuti."
metadata:
  version: "0.0.1"
  status: "isolated-probe"
---

# AMS Router Probe

Questo è un test isolato dell'architettura, non una versione del Marketing Agent System. Non modificare skill, plugin o artefatti esterni e non eseguire pubblicazioni, contatti, spesa o configurazioni.

## Scegliere il metodo

Seleziona un solo playbook per turno:

1. Se l'utente parte da un obiettivo, problema, opportunità o tattica senza una sfida confermata, leggi integralmente [il playbook della sfida](references/challenge.md).
2. Se esiste una sfida confermata e l'utente deve confrontare possibili strade, leggi integralmente [il playbook delle direzioni](references/direction.md).
3. Se entrambi restano plausibili, poni una sola domanda decisiva.

Non invocare, delegare o simulare le skill sorelle del plugin. Il metodo del router proviene soltanto dai playbook interni.

## Continuità osservabile

Alla fine di ogni risposta sostanziale aggiungi un blocco breve:

```text
STATO_PROBE
- fase: challenge | direction
- confermato: ...
- ancora_da_decidere: ...
```

Nei turni successivi usa solo ciò che compare nella conversazione o nei materiali autorizzati. Rileggi il playbook della fase attiva prima di continuare, soprattutto dopo una compattazione. Non dichiarare confermato ciò che l'utente non ha confermato esplicitamente.

## Limiti del test

Il probe misura scoperta, invocazione, isolamento e continuità. Non dimostra la qualità completa delle skill originali, l'efficacia con marketer reali o l'idoneità alla pubblicazione.

